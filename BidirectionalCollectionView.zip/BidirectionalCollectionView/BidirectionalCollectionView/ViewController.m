//
//  ViewController.m
//  BidirectionalCollectionView
//
//  Created by Souvick Ghosh on 11/04/16.
//  Copyright © 2016 souvick. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSMutableArray *arrData;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    _collectionViewMain.frame = CGRectMake(0, 50.0, 60*30, _collectionViewMain.frame.size.height);
    _collectionViewTop.frame = CGRectMake(0, 0.0, 60*30, _collectionViewTop.frame.size.height);
    _scrollViewMain.contentSize = CGSizeMake(_collectionViewTop.frame.size.width, _collectionViewMain.frame.size.height);
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if(collectionView.tag==102)
        return 900;
    else if(collectionView.tag==103)
        return 30;
    else if(collectionView.tag==104)
        return 30;
    else
        return 0;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    UIScrollView *otherScrollView = (scrollView == self.collectionViewMain) ? self.collectionViewSide : self.collectionViewMain;
    [otherScrollView setContentOffset:[scrollView contentOffset] animated:NO];
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    if(collectionView.tag==102) {
        static NSString *identifier = @"Cell";
        UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
        UILabel *lbl = [cell viewWithTag:101];
        lbl.text = [NSString stringWithFormat:@"%lD",(long)indexPath.row];
        return cell;
    } else if(collectionView.tag==103) {
        static NSString *identifier = @"Cell1";
        UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
        UILabel *lbl = [cell viewWithTag:101];
        lbl.text = [NSString stringWithFormat:@"%lD",(long)indexPath.row];
        return cell;
    } else if(collectionView.tag==104) {
        static NSString *identifier = @"Cell2";
        UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
        UILabel *lbl = [cell viewWithTag:101];
        lbl.text = [NSString stringWithFormat:@"%lD",(long)indexPath.row];
        return cell;
    }
    return nil;
    
    
}

@end
