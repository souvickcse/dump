//
//  ViewController.h
//  GradientBlur
//
//  Created by Souvick Ghosh on 17/01/17.
//  Copyright © 2017 souvick. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imgBG;


@end

