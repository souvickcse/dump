//
//  ViewController.m
//  GradientBlur
//
//  Created by Souvick Ghosh on 17/01/17.
//  Copyright © 2017 souvick. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+ImageEffects.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {

    float blurRadius = 6.0;
    UIImage *blurredImage = [[UIImage imageNamed:@"Screen Shot 2017-01-17 at 11.02.51 PM"] applyBlurWithRadius:blurRadius tintColor:[UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.2] saturationDeltaFactor:1.8 maskImage:nil];
    
    CAGradientLayer * layer = [CAGradientLayer layer];
    layer.frame = _imgBG.bounds;
    layer.colors = [NSArray arrayWithObjects:(id)[UIColor blackColor].CGColor, (id)[UIColor clearColor].CGColor, (id)[UIColor clearColor].CGColor, nil];
    layer.locations = @[@0.90,@0.99,@1.0];
    
    float startPointY = 5.0;
    layer.startPoint = CGPointMake(0.0, startPointY);
    layer.endPoint = CGPointMake(0.0f, 0.0f);
   
    _imgBG.layer.mask = layer;
    _imgBG.layer.masksToBounds = true;
    [_imgBG.layer insertSublayer:layer atIndex:0];
    _imgBG.image = blurredImage;
    
    
    /*Change the value of blurRadius & startPointY to make a gradient blur on the iamge*/
    
}



@end
